import ai2thor.controller
import cv2

class Robot:

    moves = {'a': 'MoveLeft', 'w': 'MoveAhead', 'd': 'MoveRight', 's': 'MoveBack'}
    rotates = {'j': -5, 'l': 5}
    looks = {'i': -5, 'k': 5}

    def __init__(self, _screen_size= 500):
        self.screen_size = _screen_size
        self.rotation = 90
        self.horizon = 0
        
        self.controller = ai2thor.controller.Controller()
        self.evt = None

    def start(self):
        
        self.controller.start(player_screen_width=self.screen_size,
                player_screen_height=self.screen_size)
        self.controller.reset('FloorPlan28')
        self.evt = self.controller.step(dict(action='Initialize',
                            gridSize=0.5,
                            rotation=self.rotation,
                            horizon=self.horizon,
                            renderClassImage=False,
                            renderObjectImage=False))
    
    def getFrame(self):
        return self.evt.cv2img

    def stop(self):
        self.controller.stop()

    def apply(self, action):
        if action in self.moves:
            self.evt = self.controller.step(dict(action=self.moves[action]))
            
        elif action in self.rotates:
            self.rotation += self.rotates[action]
            self.evt = self.controller.step(dict(action='Rotate', rotation=self.rotation))
            
        elif action in self.looks:
            self.horizon += self.looks[action]
            self.evt = self.controller.step(dict(action='Look', horizon=self.horizon))

